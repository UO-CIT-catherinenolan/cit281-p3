/*
    CIT 218 Project 3
    Name: Catherine Nolan
*/ 

module.exports = {
    coinCount
}; 
//four functions 
//1. validDenomination(coin)
    //returns true if coin function parameter is a valid coin of either 1, 5, 10, 25, 50, or 100
    // must use array indexOf() metho and !== euality operator
    // can be coded in on line of code
function validDenomination (coin) {
    return [1, 5, 10, 25, 50, 100].indexOf(coin) !== -1;
}

//2. valueFromCoinObject(obj)
    //returns calaculated value of a single coun object from the obj funtion parameter
    //must use object deconstruction to create constant variables denom and count 
    // from the obj function parameter using defualt object values of 0 for denom and count
function valueFromCoinObect (obj) {
    const {denom = 0, count= 0 } = obj; 
    return denom*count;
}

//3. valueFromArray(arr)
    //Iterates through an array of coin objects and returns final calculated value of all coin objects
    // must use Array.reduce () method and arrow function with Array.reduce() method
    // must call valueFromCoinObject()
    //*extra credit: handle scenario where arr function paramter contains another array of coins instead of an array of coin objects
function valueFromArray (arr) {                  //use Array.reduce()
    let sumOfValueArray = [];                              
    for (let i = 0; i < arr.length; i++) {
        sumOfValueArray[i] = valueFromCoinObject(arr[i])   // call valueFromCoinObject()
    }
    let totalValue = sumOfValueArray.reduce((total, num) => total+num, 0);
    return totalValue; 
 }

//4. coinCount (...coinage) (... = spread operator, put into an array, call coinObejects) 
    // coinCount ({denom: 25, count: 2}, 
    //            {denom: 10, count: 5})
    // the only exported function from the code module
    // calls and returns result of valueFromArray() whihc is the value of all coin objects with the coinage array function 
function coinCount (...coinage) {
    return valueFromArray(coinage); 
}

console.log("{}", coinCount({denom: 5, count: 3}));
console.log("{}s", coinCount({denom: 5, count: 3},{denom: 10, count: 2}));
const coins = [{denom: 25, count: 2},{denom: 1, count: 7}];
console.log("...[{}]", coinCount(...coins));












