/* 
    CIT 281 Project 3
    Name: Catherine Nolan 
*/ 

const fs = require ('fs'); 
const fastify = require ('fastify') (); 
const {coinCount} = require('./p3-module.js'); 

//GET route no query parameters
fastify.get ('/', (request, reply) => {
    fs.readFile (`${__dirname}/index.html`, (err, data) => {
        if (err) {
            console.log(err); 
            return 500
        }
        else{
            reply 
                .code(200)
                .header("Constent-Type", "text/html; charset-utf-8")
                .send(data);
        }
    })
})

//GEt route query parameters denom and count
fastify.get("/coin",(request,reply)=> {
    let {denom,count} = request.query;
    const coins = [{denom:parseInt(denom),count:parseInt(count)}];
    let coinValue = ((denom === undefined) || (count === undefined)) ? 0: coinCount(coins);

    reply
        .code(200)
        .header("Content-Type", "text/html; charset=utf-8")
        .send(`<h2>Value of ${count} of ${denom} is ${coinValue}</h2><br /><a href="/">Home</a>`);
    
});

//Get route query parameter option 
fastify.get("/coins",(request,reply)=> {
    let {option} = request.query;
    const coins = [{denom: 25,count: 2},{denom: 1,count: 7}];
    let coinValue;
    switch(option){
        case "1" :
            coinValue = coinCount({denom:5,count:3},{denom:10,count:2}); //option = 1
            break;
        case "2":
            coinValue = coinCount(...coins); //option = 2
            break;
        case "3":
            coinValue = coinCount(coins); //Extra credit: option = 3
            break;
        default :
            coinValue = 0;
    }

    reply
        .code(200)
        .header("Content-Type", "text/html; charset=utf-8")
        .send(`<h2>Option ${option} value is ${coinValue}</h2><br /><a href="/">Home</a>`);
    
});

